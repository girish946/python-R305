# python-R305
python api for [R305](http://robokits.co.in/sensors/r305-fingerprint-scanner-module)
Fingerprint module over UART.

![Alt R305 fingerprint module](img/R305.jpg)

    each module contains getHeader() and parse() methods.

    getHeader() generates the frame for the command for the specific instruction.

    the parse() for theat module parses the response of the command and shows the result.

